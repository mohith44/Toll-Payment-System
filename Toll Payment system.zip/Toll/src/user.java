
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;
import javax.swing.JOptionPane;
public class user extends javax.swing.JFrame {
    /**
     * Creates new form register
     */
    public user() {
        initComponents();
        dt();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        login = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        dat = new javax.swing.JLabel();
        tim = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TOLL PLAZA COLLECTION");
        setMinimumSize(new java.awt.Dimension(532, 381));

        jPanel1.setBackground(new java.awt.Color(51, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(51, 51, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel2.setText("SIGN IN");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 1, -1, -1));

        back.setBackground(new java.awt.Color(102, 102, 255));
        back.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        back.setForeground(new java.awt.Color(51, 51, 255));
        back.setText("<<");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 1, -1, -1));

        jLabel3.setBackground(new java.awt.Color(153, 153, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("USERNAME");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(76, 82, -1, -1));

        jLabel4.setBackground(new java.awt.Color(102, 153, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("PASSWORD");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(76, 182, -1, -1));

        username.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameActionPerformed(evt);
            }
        });
        jPanel1.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(266, 83, 162, -1));

        password.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel1.add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(266, 179, 162, -1));

        login.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        login.setText("LOGIN");
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });
        jPanel1.add(login, new org.netbeans.lib.awtextra.AbsoluteConstraints(118, 247, -1, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton2.setText("REGISTER");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(281, 247, -1, -1));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setText("FORGOT PASSWORD");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 310, -1, -1));

        dat.setForeground(new java.awt.Color(4, 142, 170));
        dat.setText("date");
        jPanel1.add(dat, new org.netbeans.lib.awtextra.AbsoluteConstraints(472, 126, -1, -1));

        tim.setForeground(new java.awt.Color(4, 142, 170));
        tim.setText("time");
        jPanel1.add(tim, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 160, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/toll.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, -6, 540, 390));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameActionPerformed

        // TODO add your handling code here:
    }//GEN-LAST:event_usernameActionPerformed

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
String u=username.getText();
String p=password.getText();
if(username.getText().equals("")|| password.getText().equals(""))
{
JOptionPane.showMessageDialog(null,"Please Enter Data in All fields First."); return;
}
String v="Paid/not verified";
if(refund.refundamount(username.getText(), dat.getText(), v) && LoginCheck.checkCredentials(username.getText(),password.getText()) && lost.lostvehicle(username.getText())){

    System.out.println("Logged in as : "+username.getText());
JOptionPane.showMessageDialog(null,"You are now logged in as "+username.getText(),"message",JOptionPane.INFORMATION_MESSAGE);
try
{
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();
String code = "SELECT wallet FROM userregister where username='"+username.getText()+"'";
ResultSet rec = s.executeQuery(code);
while(rec.next())
{
//if(u.equals(rec.getString("username")) && p.equals(rec.getString("password")))
//{
String wallet=rec.getString("wallet");
String a;
a=username.getText();
useraccount useraccount=new useraccount();
useraccount.username.setText(a);
useraccount.wallet.setText(wallet);
useraccount.alert.setText("Toll plaza collection found you vehicle contact customer support");
useraccount.refund.setText("Yesterdays amount refunded");
useraccount.setVisible(true);
this.setVisible(false);
//JOptionPane.showMessageDialog(null,"Logged in successfully");
//}
}
/*catch(Exception ex)
{
JOptionPane.showMessageDialog(null,"ERROR :Invalid username or password");
System.out.println(ex);
}  
        }        }}*/
}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null,"ERROR :Invalid username or password");
}
}
else if(refund.refundamount(username.getText(), dat.getText(), v) && LoginCheck.checkCredentials(username.getText(),password.getText())){

    System.out.println("Logged in as : "+username.getText());
JOptionPane.showMessageDialog(null,"You are now logged in as "+username.getText(),"message",JOptionPane.INFORMATION_MESSAGE);
try
{
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();
String code = "SELECT wallet FROM userregister where username='"+username.getText()+"'";
ResultSet rec = s.executeQuery(code);
while(rec.next())
{
//if(u.equals(rec.getString("username")) && p.equals(rec.getString("password")))
//{
String wallet=rec.getString("wallet");
String a;
a=username.getText();
useraccount useraccount=new useraccount();
useraccount.username.setText(a);
useraccount.wallet.setText(wallet);
useraccount.refund.setText("Yesterdays amount refunded");
useraccount.setVisible(true);
this.setVisible(false);
//JOptionPane.showMessageDialog(null,"Logged in successfully");
//}
}
/*catch(Exception ex)
{
JOptionPane.showMessageDialog(null,"ERROR :Invalid username or password");
System.out.println(ex);
}  
        }        }}*/
}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null,"ERROR :Invalid username or password");
}
}



else if(lost.lostvehicle(username.getText())&&LoginCheck.checkCredentials(username.getText(),password.getText())){

    System.out.println("Logged in as : "+username.getText());
JOptionPane.showMessageDialog(null,"You are now logged in as "+username.getText(),"message",JOptionPane.INFORMATION_MESSAGE);
try
{
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();
String code = "SELECT wallet FROM userregister where username='"+username.getText()+"'";
ResultSet rec = s.executeQuery(code);
while(rec.next())
{
//if(u.equals(rec.getString("username")) && p.equals(rec.getString("password")))
//{
String wallet=rec.getString("wallet");
String a;
a=username.getText();
useraccount useraccount=new useraccount();
useraccount.username.setText(a);
useraccount.wallet.setText(wallet);
useraccount.alert.setText("Toll plaza collection found you vehicle contact customer support");
useraccount.setVisible(true);
this.setVisible(false);
//JOptionPane.showMessageDialog(null,"Logged in successfully");
//}
}
/*catch(Exception ex)
{
JOptionPane.showMessageDialog(null,"ERROR :Invalid username or password");
System.out.println(ex);
}  
        }        }}*/
}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null,"ERROR :Invalid username or password");
}
}


else if(LoginCheck.checkCredentials(username.getText(),password.getText()))
{
System.out.println("Logged in as : "+username.getText());
JOptionPane.showMessageDialog(null,"You are now logged in as "+username.getText(),"message",JOptionPane.INFORMATION_MESSAGE);
try
{
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();
String code = "SELECT wallet FROM userregister where username='"+username.getText()+"'";
ResultSet rec = s.executeQuery(code);
while(rec.next())
{
//if(u.equals(rec.getString("username")) && p.equals(rec.getString("password")))
//{
String wallet=rec.getString("wallet");
String a;
a=username.getText();
useraccount useraccount=new useraccount();
useraccount.username.setText(a);
useraccount.wallet.setText(wallet);
useraccount.setVisible(true);
this.setVisible(false);
//JOptionPane.showMessageDialog(null,"Logged in successfully");
//}
}
/*catch(Exception ex)
{
JOptionPane.showMessageDialog(null,"ERROR :Invalid username or password");
System.out.println(ex);
}  
        }        }}*/
}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex);
}}
else
{
System.out.println("Invalid Username/Password"); //displayError("Invalid Credentials");
}

// TODO add your handling code here:
    }//GEN-LAST:event_loginActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
userregister userregister=new userregister();
userregister.setVisible(true);
this.setVisible(false);
// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
     userforgotpassword userforgotpassword=new userforgotpassword();
     userforgotpassword.setVisible(true);
this.setVisible(false);
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        main main=new main();
        main.setVisible(true);
        this.setVisible(false);
        // TODO add your handling code here:
    }//GEN-LAST:event_backActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(user.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new userregister().setVisible(true);
            }
        });
    }
public void dt(){
Calendar Calendar= new GregorianCalendar();
int month=Calendar.get(Calendar.MONTH);
int year=Calendar.get(Calendar.YEAR);
int day=Calendar.get(Calendar.DAY_OF_MONTH);
dat.setText((day+"-"+(month+1)+"-"+year));
int second=Calendar.get(Calendar.SECOND);
int minute=Calendar.get(Calendar.MINUTE);
int hour=Calendar.get(Calendar.HOUR);
tim.setText(hour+":"+minute+":"+second);
 Date date = Calendar.getInstance().getTime();  
                DateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy");  
                String strDate = dateFormat.format(date);  
}
  



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    public javax.swing.JLabel dat;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton login;
    private javax.swing.JPasswordField password;
    public javax.swing.JLabel tim;
    public javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
class LoginCheck
{
static boolean checkCredentials(String u,String p)
{
try
{
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();
String code = "SELECT username,password FROM userregister";
ResultSet rec = s.executeQuery(code);
while(rec.next())
{
if(u.equals(rec.getString("username")) && p.equals(rec.getString("password")))
return true;
}
return false;
}
catch(Exception e)
{
System.out.println(e);
}
return false;
}
private void displayError(String err)
{
JOptionPane.showMessageDialog(null,err,"ERROR",JOptionPane.ERROR_MESSAGE);
}
}
class lost{
static boolean lostvehicle(String u){

try
{
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();
String code = "SELECT username,vehicle_no,complaint, status FROM feedback";
ResultSet rec = s.executeQuery(code);
while(rec.next())
{
    String l="I lost my vehicle";
    String sta="Found";
if(u.equals(rec.getString("username")) && l.equals(rec.getString("complaint")) && sta.equals(rec.getString("status")))
{     try
{
    String ur="com.mysql.cj.jdbc.Driver";

Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
 Statement stt = conn.createStatement();
 stt.executeUpdate("UPDATE feedback SET status='Informed' where username='"+u+"' AND complaint='I lost my vehicle' ");

 stt.close();

 //ResultSet r = st.executeQuery(code);
}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex);
}
return true;}
}
return false;
}
catch(Exception e)
{
System.out.println(e);
}
return false;
}
private void displayError(String err)
{
JOptionPane.showMessageDialog(null,err,"ERROR",JOptionPane.ERROR_MESSAGE);
}
}


class refund{
static boolean refundamount(String u,String d,String v){
try
{
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();
String sql="select * from history where username='"+u+"' AND verification='Paid/not verified'";
ResultSet rec = s.executeQuery(sql);
while(rec.next())
{String toll_names=rec.getString("toll_name");
String vehicle_number=rec.getString("vehicle_number");
String date=rec.getString("date");
if(!d.equals(rec.getString("date")) && v.equals(rec.getString("verification"))){

try{
   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement st = con.createStatement();

String code="select wallet from userregister where username='"+u+"'" ;
ResultSet r=st.executeQuery(code); 

while(r.next()){
 String am=r.getString("wallet");
 
 String cost=String.valueOf(rec.getInt("amount"));
            int amo=Integer.parseInt(am);
            int amou=Integer.parseInt(cost);
            int add=amo+amou;
            String amoun=String.valueOf(add);
            System.out.println(add);
          //  wallet.setText(amoun);
if(rec.getString("verification").equals("Paid/not verified")){
    System.out.println(rec.getString("verification"));
    
    
    try
{
    String ur="com.mysql.cj.jdbc.Driver";

Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
 Statement stt = co.createStatement();
 stt.executeUpdate("UPDATE history SET verification='Refunded' where date='"+date+"' AND toll_name='"+toll_names+"' AND vehicle_number='"+vehicle_number+"'");
  stt.executeUpdate("UPDATE userregister SET wallet='"+amoun+"' where username='"+u+"'");

 stt.close();

 //ResultSet r = st.executeQuery(code);
}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex);
}
}}}
  catch(Exception ex)
{
//JOptionPane.showMessageDialog(null,"ERROR : Cannot get data into database");
System.out.println(ex);
}



return true;
}
}
return false;
}
catch(Exception e)
{
System.out.println(e);
}
    return false;
}
}

/*
String co="SELECT status FROM `feedback` WHERE status='Found' AND username='"+username+"'";
ResultSet r=st.executeQuery(co); 
while(r.next()){
String nt=r.getString("status");
if(nt.equals("Found")){
    String al="Toll plaza collection found you vehicle contact customer support";
    useraccount useraccount=new useraccount();
useraccount.username.setText(user);
useraccount.wallet.setText(amoun);
useraccount.alert.setText(al);
useraccount.setVisible(true);
this.setVisible(false);
}
else{
useraccount useraccount=new useraccount();
useraccount.username.setText(user);
useraccount.wallet.setText(amoun);
useraccount.alert.setText("");
useraccount.setVisible(true);
this.setVisible(false);
}}
*/
/*
String u=username.getText();
String p=password.getText();
if(username.getText().equals("")|| password.getText().equals(""))
{
JOptionPane.showMessageDialog(null,"Please Enter Data in All fields First."); return;
}
if(LoginCheck.checkCredentials(username.getText(),password.getText()))
{

try
{
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();

{
  try{
String user=username.getText();

String sql="select * from history where username='"+user+"' AND verification='Paid/not verified'";
ResultSet rs=s.executeQuery(sql); 
//ResultSet rec=s.executeQuery(code); 
while(rs.next()){
String username=rs.getString("username");
String start=rs.getString("start");
String end=rs.getString("end");
String toll_names=rs.getString("toll_name");
String vehicle_type=rs.getString("vehicle_type");
String vehicle_number=rs.getString("vehicle_number");
String amount=String.valueOf(rs.getInt("amount"));
String verification=rs.getString("verification");
String da=rs.getString("date");
String ti=rs.getString("time");
String date=dat.getText();
String time=tim.getText();

 SimpleDateFormat simpleDateFormat
            = new SimpleDateFormat("HH:mm:ss");
 Date date1 = simpleDateFormat.parse(ti);
        Date date2 = simpleDateFormat.parse(time);
        long differenceInMilliSeconds
            = Math.abs(date2.getTime() - date1.getTime());
  
        long differenceInHours
            = (differenceInMilliSeconds / (60 * 60 * 1000))
              % 24;
        System.out.println(da);
System.out.println(date); 
  if(!da.equalsIgnoreCase(date)){
    System.out.println(differenceInHours);
       // if(differenceInHours>24){
     System.out.println(da);
System.out.println(date);     
        
     //username='"+username+"'  
   //   ResultSet rss = s.executeQuery(co);
   try{
   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement st = con.createStatement();

String code="select wallet from userregister where username='"+username+"'" ;
ResultSet rec=st.executeQuery(code); 

while(rec.next()){
 String am=rec.getString("wallet");
 String cost=String.valueOf(rs.getInt("amount"));
            int amo=Integer.parseInt(am);
            int amou=Integer.parseInt(cost);
            int add=amo+amou;
            String amoun=String.valueOf(add);
            System.out.println(add);
          //  wallet.setText(amoun);
          System.out.println(da);
          System.out.println(toll_names);
          System.out.println(vehicle_number);
           System.out.println(rs.getString("verification"));
if(rs.getString("verification").equals("Paid/not verified")){
    System.out.println(rs.getString("verification"));
st.executeUpdate("UPDATE history SET verification='Refunded' where date='"+da+"' AND toll_name='"+toll_names+"' AND vehicle_number='"+vehicle_number+"'");
  st.executeUpdate("UPDATE userregister SET wallet='"+amoun+"' where username='"+username+"'");
}
String wallet=rec.getString("wallet");
//String username=rec.getString("username");
useraccount useraccount=new useraccount();
useraccount.username.setText(username);
useraccount.wallet.setText(wallet);
useraccount.setVisible(true);
this.setVisible(false);

System.out.println("Logged in as : "+username);
JOptionPane.showMessageDialog(null,"You are now logged in as "+username,"message",JOptionPane.INFORMATION_MESSAGE);

//String a=username.getText();
}
    
   
}
  catch(Exception ex)
{
//JOptionPane.showMessageDialog(null,"ERROR : Cannot get data into database");
System.out.println(ex);
} } 
    else{
         try
{

String cod = "SELECT wallet FROM userregister where username='"+username+"'";
ResultSet rec = s.executeQuery(cod);
while(rec.next()){
{

String wallet=rec.getString("wallet");

useraccount useraccount=new useraccount();
useraccount.username.setText(username);
useraccount.wallet.setText(wallet);
useraccount.setVisible(true);
this.setVisible(false);

}}}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex);
} }}}
catch(Exception ex)
{
//JOptionPane.showMessageDialog(null,"ERROR : Cannot get data into database");
System.out.println(ex);
}  
JOptionPane.showMessageDialog(null,"Logged in successfully");
//}
  
}

}
catch(Exception ex)
{
//JOptionPane.showMessageDialog(null, ex);
}}
else
{
System.out.println("Invalid Username/Password"); //displayError("Invalid Credentials");
}
try
{
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = con.createStatement();
String cod = "SELECT wallet FROM userregister where username='"+username+"'";
ResultSet rec = s.executeQuery(cod);
while(rec.next()){
{

String wallet=rec.getString("wallet");
String username=rec.getString("username");
useraccount useraccount=new useraccount();
useraccount.username.setText(username);
useraccount.wallet.setText(wallet);
useraccount.setVisible(true);
this.setVisible(false);

}}}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex);
}
*/
/*
String u=username.getText();
String p=password.getText();

if(username.getText().equals("")|| password.getText().equals(""))
{
JOptionPane.showMessageDialog(null,"Please Enter Data in All fields First."); return;
}
if(LoginCheck.checkCredentials(username.getText(),password.getText())){
try
{
    
String url="com.mysql.cj.jdbc.Driver";
Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement s = c.createStatement();
String sql="select * from history where username='"+u+"' AND verification='Paid/not verified'";
ResultSet rs=s.executeQuery(sql); 
System.out.println("1");
while(rs.next()){
    System.out.println("2");
String username=rs.getString("username");
String start=rs.getString("start");
String end=rs.getString("end");
String toll_names=rs.getString("toll_name");
String vehicle_type=rs.getString("vehicle_type");
String vehicle_number=rs.getString("vehicle_number");
String amount=String.valueOf(rs.getInt("amount"));
String verification=rs.getString("verification");
String da=rs.getString("date");
String ti=rs.getString("time");
String date=dat.getText();
String time=tim.getText();

 SimpleDateFormat simpleDateFormat
            = new SimpleDateFormat("HH:mm:ss");
 Date date1 = simpleDateFormat.parse(ti);
        Date date2 = simpleDateFormat.parse(time);
        long differenceInMilliSeconds
            = Math.abs(date2.getTime() - date1.getTime());
  
        long differenceInHours
            = (differenceInMilliSeconds / (60 * 60 * 1000))
              % 24;
        System.out.println(da);
System.out.println(date); 
 if(!da.equalsIgnoreCase(date)){
    System.out.println(differenceInHours);
       // if(differenceInHours>24){
     System.out.println(da);
System.out.println(date);
   try{
   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement st = con.createStatement();

String code="select wallet from userregister where username='"+username+"'" ;
ResultSet rec=st.executeQuery(code); 



while(rec.next()){
 String am=rec.getString("wallet");
 String cost=String.valueOf(rs.getInt("amount"));
            int amo=Integer.parseInt(am);
            int amou=Integer.parseInt(cost);
            int add=amo+amou;
            String amoun=String.valueOf(add);
            System.out.println(add);
          //  wallet.setText(amoun);
          System.out.println(da);
          System.out.println(toll_names);
          System.out.println(vehicle_number);
           System.out.println(rs.getString("verification"));
if(rs.getString("verification").equals("Paid/not verified")){
    System.out.println(rs.getString("verification"));
st.executeUpdate("UPDATE history SET verification='Refunded' where date='"+da+"' AND toll_name='"+toll_names+"' AND vehicle_number='"+vehicle_number+"'");
  st.executeUpdate("UPDATE userregister SET wallet='"+amoun+"' where username='"+username+"'");
String co="SELECT status FROM `feedback` WHERE status='Found' AND username='"+username+"'";
ResultSet r=st.executeQuery(co); 
  while(r.next()){
String nt=r.getString("status");
System.out.println(nt);
if(nt.equals("Found")){
   String  ale="Toll plaza collection found you vehicle contact customer support";
  
  useraccount useraccount=new useraccount();
useraccount.username.setText(u);
useraccount.wallet.setText(amoun);
useraccount.alert.setText(ale);
useraccount.setVisible(true);
this.setVisible(false);}
else{
useraccount useraccount=new useraccount();
useraccount.username.setText(u);
useraccount.wallet.setText(amoun);
useraccount.setVisible(true);
this.setVisible(false);}
  
  }}
useraccount useraccount=new useraccount();
useraccount.username.setText(u);
useraccount.wallet.setText(amoun);
useraccount.setVisible(true);
this.setVisible(false);

System.out.println("Logged in as : "+u);
JOptionPane.showMessageDialog(null,"You are now logged in as "+u,"message",JOptionPane.INFORMATION_MESSAGE);


}}
 catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex);
}
 }
 
 else
{
        try
{
Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/toll","root","");
Statement ste = co.createStatement();
String cod = "SELECT wallet FROM userregister where username='"+u+"'";
ResultSet re = ste.executeQuery(cod);
while(re.next()){
{

String wallet=re.getString("wallet");

useraccount useraccount=new useraccount();
useraccount.username.setText(u);
useraccount.wallet.setText(wallet);
useraccount.setVisible(true);
this.setVisible(false);
System.out.println("Logged in as : "+u);
JOptionPane.showMessageDialog(null,"You are now logged in as "+u,"message",JOptionPane.INFORMATION_MESSAGE);

}}}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex);
}
}
 
 
 
}}
catch(Exception ex)
{
JOptionPane.showMessageDialog(null, ex);
}

        }
else{
System.out.println("Invalid Username/Password"); //displayError("Invalid Credentials");
        }
// TODO add your handling code here:
    }                 
*/